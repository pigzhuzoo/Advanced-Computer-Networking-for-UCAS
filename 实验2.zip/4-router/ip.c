#include "ip.h"
#include "icmp.h"
#include "log.h"

#include <stdio.h>
#include <stdlib.h>

// handle ip packet
//
// If the packet is ICMP echo request and the destination IP address is equal to
// the IP address of the iface, send ICMP echo reply; otherwise, forward the
// packet.
void handle_ip_packet(iface_info_t *iface, char *packet, int len)
{
    struct iphdr *ip = packet_to_ip_hdr(packet);
    u32 daddr = ntohl(ip->daddr);
    if (daddr == iface->ip) {
        if (ip->protocol == IPPROTO_ICMP) {
            struct icmphdr *icmp = (struct icmphdr *)IP_DATA(ip);
            if (icmp->type == ICMP_ECHOREQUEST) {
                icmp_send_packet(packet, len, ICMP_ECHOREPLY, 0);
            }
        }
        free(packet);
    }
    else {
        ip_forward_packet(daddr, packet, len);
        log(ERROR, "received packet with incorrect destination IP address.");
    }
}
