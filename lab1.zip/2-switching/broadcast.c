#include "base.h"
#include <stdio.h>

// XXX ifaces are stored in instace->iface_list
extern ustack_t *instance;

extern void iface_send_packet(iface_info_t *iface, const char *packet, int len);

void broadcast_packet(iface_info_t *iface, const char *packet, int len)
{
	// TODO: broadcast packet 
	iface_info_t *ifa=NULL;
	list_for_each_entry(ifa, &instance->iface_list, list){
		if(ifa->index!=iface->index)
		{
			iface_send_packet(ifa,packet,len);
			fprintf(stdout, "TODO: broadcast packet.\n");
		}
		//		if(memcmp(&iface->mac,&ifa->mac,sizeof(iface->mac)))
		
	}
}
